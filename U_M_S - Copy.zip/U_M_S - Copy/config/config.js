// config/config.js

module.exports = {
    development: {
      username: 'root',
      password: 'root',
      database: 'u_m_s',
      host: 'localhost',
      dialect: 'mysql',
      SECRET_KEY: 'hdjhifugifg'
    },
    production: {
      // Production database configuration
    },

  };