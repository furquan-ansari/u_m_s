// controllers/adminController.js

const { Role, Page, User } = require('../models');

exports.assignRole = async (req, res) => {
  try {
    const { userId, roleId } = req.body;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    const role = await Role.findByPk(roleId);
    if (!role) {
      return res.status(404).json({ message: 'Role not found' });
    }
    await user.addRole(role);
    res.status(200).json({ message: 'Role assigned successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to assign role' });
  }
};

exports.assignPageAccess = async (req, res) => {
  try {
    const { userId, pageId } = req.body;
    const user = await User.findByPk(userId);
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    const page = await Page.findByPk(pageId);
    if (!page) {
      return res.status(404).json({ message: 'Page not found' });
    }
    await user.addPage(page);
    res.status(200).json({ message: 'Page access assigned successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Failed to assign page access' });
  }
};
