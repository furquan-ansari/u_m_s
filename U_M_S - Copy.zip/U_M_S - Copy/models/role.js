// models/role.js

module.exports = (sequelize, DataTypes) => {
    const Role = sequelize.define('Role', {
      name: DataTypes.STRING
    });

    return Role;
  };
