// models/index.js

const Sequelize = require('sequelize');
const config = require('../config/config');

const sequelize = new Sequelize(config.development.database, config.development.username, config.development.password, {
  host: config.development.host,
  dialect: config.development.dialect
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

// Models
db.User = require('./user')(sequelize, Sequelize);
db.Role = require('./role')(sequelize, Sequelize);
db.Page = require('./page')(sequelize, Sequelize);

// Associations
db.Role.belongsToMany(db.User, { through: 'UserRole' });
db.User.belongsToMany(db.Role, { through: 'UserRole' });

db.Page.belongsToMany(db.User, { through: 'UserPage' });
db.User.belongsToMany(db.Page, { through: 'UserPage' });

module.exports = db;
