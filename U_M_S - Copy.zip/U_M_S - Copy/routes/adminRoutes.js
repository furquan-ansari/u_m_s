// routes/adminRoutes.js

const express = require('express');
const router = express.Router();
const { authenticateUser } = require('../middleware/authMiddleware');
const { assignRole, assignPageAccess } = require('../controllers/adminController');

router.post('/assign-role', authenticateUser, assignRole);
router.post('/assign-page-access', authenticateUser, assignPageAccess);

module.exports = router;
