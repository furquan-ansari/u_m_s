// routes/authRoutes.js

const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/authMiddleware.js')
const { register, login } = require('../controllers/authController');

router.post('/register',authMiddleware,register);
router.post('/login', login);

module.exports = router;
