// routes/userRoutes.js

const express = require('express');
const router = express.Router();
const { authenticateUser } = require('../middleware/authMiddleware');
const { getAllUsers } = require('../controllers/userController');

router.get('/', authenticateUser, getAllUsers);

module.exports = router;
