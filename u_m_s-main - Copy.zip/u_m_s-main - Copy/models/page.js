// models/page.js

module.exports = (sequelize, DataTypes) => {
    const Page = sequelize.define('Page', {
      name: DataTypes.STRING
    });

    return Page;
  };
